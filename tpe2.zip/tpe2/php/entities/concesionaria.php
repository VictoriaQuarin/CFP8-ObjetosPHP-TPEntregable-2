<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../interfaces/i_concesionaria.php";


class Concesionaria implements I_Concesionaria{

    private $vehiculos = [];


    public function listar() {
        return $this->vehiculos;
    }



    // ---------------

    // Intento de resolución, teniendo en cuenta el ejemplo de la Clase 12.
    public function mayorPrecio() {
        $vehiculoMayorPrecio = $this->vehiculos[0];

        foreach ($this->vehiculos as $vehiculo) {
            if ($vehiculo->__get("precio") > $vehiculoMayorPrecio->__get("precio")) {
                $vehiculoMayorPrecio = $vehiculo;
            }
        }

        return $vehiculoMayorPrecio;
    }
    
    
    public function menorPrecio() {
        $vehiculoMenorPrecio = $this->vehiculos[0];

        foreach ($this->vehiculos as $vehiculo) {
           if ($vehiculo->__get("precio") < $vehiculoMenorPrecio->__get("precio")) {
                $vehiculoMenorPrecio = $vehiculo;
           }
        }

        return $vehiculoMenorPrecio;
    }

    // ---------------


    public function ordenNatural()  {}

    public function ordenPrecio() {}

    public function contieneY() {}

    public function agregarVehiculo(Vehiculo $vehiculo){
        $this->vehiculos[] = $vehiculo;
    }


}
?>