<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../interfaces/i_concesionaria.php";


class Concesionaria implements I_Concesionaria{

    private $vehiculos = [];


    public function listar() {
        return $this->vehiculos;
    }


    public function mayorPrecio() {
        $vehiculoMayorPrecio = $this->vehiculos[0];

        foreach ($this->vehiculos as $vehiculo) {
            if ($vehiculo->__get("precio") > $vehiculoMayorPrecio->__get("precio")) {
                $vehiculoMayorPrecio = $vehiculo;
            }
        }

        return $vehiculoMayorPrecio;
    }


    public function menorPrecio() {
        $vehiculoMenorPrecio = $this->vehiculos[0];

        foreach ($this->vehiculos as $vehiculo) {
            if ($vehiculo->__get("precio") < $vehiculoMenorPrecio->__get("precio")) {
                $vehiculoMenorPrecio = $vehiculo;
            }
        }

        return $vehiculoMenorPrecio;
    }


    //TRES USORT - ORDEN POR PRECIO, MODELO, MARCA. EN ESE ORDEN. 

    public function ordenNatural()  {
        usort ($this->vehiculos, function($a,$b) : int{
            return $b->__get("precio") <=> $a->__get("precio");
        });
        usort ($this->vehiculos, function($a,$b) : int {
            return $b->__get("marca") <=> $a->__get("marca");
        });
        usort ($this->vehiculos, function($a,$b) : int {
            return $b->__get("modelo") <=> $a->__get("modelo");
        });
    }


    //USO DE LA FUNCIÓN USORT - FUNCIÓN PARA ORDERNAR VECTORES. CONTIENE TÉCNICAS DE ORDENAMIENTO. 
    //USO DEL OPERADOR <=> (Nave Espacial), hace una evaluación de los valores. Si éstos valores son iguales, devuelve cero. 
    // 0 <=> 0          // 0
    // 16 <=> 16        // 0
    // 5 <=> 6          // - 1
    // 6 <=> 5          // -1

    // Internamente, el USORT genera un FOR, aplica el método 'burbujeo'. Recorre de ésta forma el string, hasta obtener el vector ordenado. 
    public function ordenPrecio(): void {
        usort ($this->vehiculos, function($a,$b) : int {
            return $b->__get("precio") <=> $a->__get("precio");
        });
        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo->__get('marca').' '.$vehiculo->__get('modelo');
        }
    }



    // Recorre el string, consultando si hay o no letra 'Y'.
    public function contieneY() : Vehiculo | null {
        $vehiculoY = null;
        
        foreach ($this->vehiculos as $vehiculo) {
            if (str_contains($vehiculo->__get("marca"), "y"))
                $vehiculoY = $vehiculo;
            }
        return $vehiculoY;
    }


    public function agregarVehiculo(Vehiculo $vehiculo){
        $this->vehiculos[] = $vehiculo;
    }


}
?>