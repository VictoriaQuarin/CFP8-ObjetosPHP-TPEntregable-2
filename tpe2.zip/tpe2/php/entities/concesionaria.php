<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../interfaces/i_concesionaria.php";


class Concesionaria implements I_Concesionaria{

    private $vehiculos = [];


    public function listar() {
        return $this->vehiculos;
    }


    public function mayorPrecio() {
        $vehiculoMayorPrecio = $this->vehiculos[0];

        foreach ($this->vehiculos as $vehiculo) {
            if ($vehiculo->__get("precio") > $vehiculoMayorPrecio->__get("precio")) {
                $vehiculoMayorPrecio = $vehiculo;
            }
        }
        return "<br>Vehículo más caro: " .$vehiculoMayorPrecio->__get("marca") . " " . $vehiculoMayorPrecio->__get("modelo");
    }


    public function menorPrecio() {
        $vehiculoMenorPrecio = $this->vehiculos[0];

        foreach ($this->vehiculos as $vehiculo) {
            if ($vehiculo->__get("precio") < $vehiculoMenorPrecio->__get("precio")) {
                $vehiculoMenorPrecio = $vehiculo;
            }
        }
        return "Vehículo más barato: " .$vehiculoMenorPrecio->__get("marca") . " " .$vehiculoMenorPrecio->__get("modelo");
    }


    public function ordenNatural()  {
        usort ($this->vehiculos, function($a,$b) : int{
            return $a->__get("precio") <=> $b->__get("precio");
        });
        usort ($this->vehiculos, function($a,$b) : int {
            return $a->__get("modelo") <=> $b->__get("modelo");
        });
        usort ($this->vehiculos, function($a,$b) : int {
            return $a->__get("marca") <=> $b->__get("marca");
        });
    }


    //USO DE LA FUNCIÓN USORT - FUNCIÓN PARA ORDERNAR VECTORES. CONTIENE TÉCNICAS DE ORDENAMIENTO. 
    //USO DEL OPERADOR <=> (Nave Espacial), hace una evaluación de los valores. Si éstos valores son iguales, devuelve cero. 
    // 0 <=> 0          // 0
    // 16 <=> 16        // 0
    // 5 <=> 6          // - 1
    // 6 <=> 5          // -1

    // Internamente, el USORT genera un FOR, aplica el método 'burbujeo'. Recorre de ésta forma el string, hasta obtener el vector ordenado. 
    public function ordenPrecio(): void {
        usort ($this->vehiculos, function($a,$b) : int {
            return $b->__get("precio") <=> $a->__get("precio");
        });
        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo->__get('marca').' '.$vehiculo->__get('modelo').'<br>';
        }
    }


    // Recorre el string, consultando si hay o no letra 'Y'.
    public function contieneY() : string {
        $vehiculoY = null;
        
        foreach ($this->vehiculos as $vehiculo) {
            if (str_contains($vehiculo->__get("modelo"), "Y")) {
                $vehiculoY = $vehiculo;
                break;
            }
        }

        if ($vehiculoY) {
                return "Vehículo que contiene en el modelo a letra 'Y': ".$vehiculoY->__get("marca"). " " 
                    .$vehiculoY->__get("modelo") . " $" . number_format($vehiculoY->__get("precio"), 2, ',', '.'). "<br>";
        } else {
            return "No se encontró un vehículo con 'Y' en el modelo.<br>";
        }
    }


    public function agregarVehiculo(Vehiculo $vehiculo){
        $this->vehiculos[] = $vehiculo;
    }


}
?>