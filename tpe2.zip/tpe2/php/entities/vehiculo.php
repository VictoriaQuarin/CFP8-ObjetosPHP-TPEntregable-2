<?php
require_once "../entities/vehiculo.php";

abstract class Vehiculo{
    private $marca;
    private $modelo;
    private $precio;


    public function __construct(string $marca, string $modelo){
        $this->marca = $marca;
        $this->modelo = $modelo;
    }


    public function __tostring(): string{
        return $this->marca.",".$this->modelo;
    }


    public function __get($property){
        if(property_exists($this, $property)){
            return $this->$property;
        }
    }


    public function __set($property, $value){
        if(property_exists($this, $property)){
            $this->$property = $value;
        }
    }
    
}
?>