<?php
require_once "../entities/auto.php";

class Auto extends Vehiculo{
    private $puertas;


    public function __construct(string $marca, string $modelo, int $puertas, float $precio){
        parent::__construct($marca, $modelo);
        $this->puertas = $puertas;
        $this->precio = $precio;
    }


    public function __tostring(): string{
        return "Marca: ".$this->marca." // Modelo: ".$this->modelo." // Puertas: "
            .$this->puertas." // Precio: $".number_format($this->precio, 2, ',', '.')."";
    }
}
?>