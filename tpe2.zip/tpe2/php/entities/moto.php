<?php
require_once "../entities/moto.php";

class Moto extends Vehiculo{
    private $cilindrada;


    public function __construct(string $marca, string $modelo, string $cilindrada, float $precio){
        parent::__construct($marca, $modelo);
        $this->cilindrada = $cilindrada;
        $this->precio = $precio;
    }


    public function __tostring(): string{
        return parent::__tostring().",".$this->cilindrada.",".$this->__get("precio");
    }
    
}
?>