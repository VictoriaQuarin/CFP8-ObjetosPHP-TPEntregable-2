<?php
require_once "../entities/moto.php";

class Moto extends Vehiculo{
    private $cilindrada;


    public function __construct(string $marca, string $modelo, string $cilindrada, float $precio){
        parent::__construct($marca, $modelo);
        $this->cilindrada = $cilindrada;
        $this->precio = $precio;
    }


    public function __tostring(): string{
        return "Marca: ".$this->marca." // Modelo: ".$this->modelo." // Cilindrada: "
            .$this->cilindrada." // Precio: $".number_format($this->precio, 2, ',', '.')."";
    }
    
}
?>