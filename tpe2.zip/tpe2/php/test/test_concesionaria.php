<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../interfaces/i_concesionaria.php";
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";


//http://localhost/objetos/tpe2/php/test/test_concesionaria.php


echo "<h1> Test TP Entregable 2 - Concesionaria </h1><br>";


// Ingreso de los registros de los vehículos.
$auto1 = new Auto("Peugeot", "206", "4", 200000.00);
$moto1 = new Moto("Honda", "Titan", "125c", 60000.00);
$auto2 = new Auto("Peugeot", "208", "5", 250000.00);
$moto2 = new Moto("Yamaha", "YBR", "160c", 80500.50);



// Creación de Concesionaria y agregado de los vehículos a Concesionaria.
$concesionaria = new Concesionaria();
$concesionaria->agregarVehiculo($auto1);
$concesionaria->agregarVehiculo($moto1);
$concesionaria->agregarVehiculo($auto2);
$concesionaria->agregarVehiculo($moto2);




// FALTA -> CORROBORAR LA ESCRITURA DE LOS MÉTODOS EN CLASS CONCESIONARIA.
// FALTA -> CONSTRUCCIÓN CORRECTA Y COMPLETA DE LAS SALIDAS PARA CADA MÉTODO.



echo "<h2> Test Listado de Vehículos </h2><br>";
$vehiculos = $concesionaria->listar();
foreach($vehiculos as $vehiculo){
    echo $vehiculo."<br>";                                      // FALTA FORMATO EN LA SALIDA.
}


echo "<br>-----------------<br>";



// TESTS INICIALES PARA CORROBORAR SI HAY O NO SALIDA.

echo "<h2> Test Vehículo más caro </h2><br>";
$vehiculoMayorPrecio = $concesionaria->mayorPrecio();
echo $vehiculoMayorPrecio."<br>";                               // FALTA FORMATO EN LA SALIDA.


echo "<h2> Test Vehículo más barato </h2><br>";
$vehiculoMenorPrecio = $concesionaria->menorPrecio();
echo $vehiculoMenorPrecio;                                      // FALTA FORMATO EN LA SALIDA.


echo "<h2> Test Vehículo Contiene Y </h2><br>";
$vehiculoY = $concesionaria->contieneY();
echo $vehiculoY;

/*
echo "<h2> Test Vehículo Orden Natural </h2><br>";
$vehiculo = $concesionaria->ordenNatural();
echo $vehiculo;


echo "<h2> Test Vehículo Orden por Precio </h2><br>";
$vehiculo = $concesionaria->ordenPrecio();             
echo $vehiculo;
*/



?>