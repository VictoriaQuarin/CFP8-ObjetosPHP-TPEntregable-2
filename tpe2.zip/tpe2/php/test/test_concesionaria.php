<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../interfaces/i_concesionaria.php";
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";


//http://localhost/objetos/tpe2/php/test/test_concesionaria.php


echo "<h1> Test TP Entregable 2 - Concesionaria </h1><br>";


// Ingreso de los registros de los vehículos.
$auto1 = new Auto("Peugeot", "206", "4", 200000.00);
$moto1 = new Moto("Honda", "Titan", "125c", 60000.00);
$auto2 = new Auto("Peugeot", "208", "5", 250000.00);
$moto2 = new Moto("Yamaha", "YBR", "160c", 80500.50);


// Creación de Concesionaria y agregado de los vehículos a Concesionaria.
$concesionaria = new Concesionaria();
$concesionaria->agregarVehiculo($auto1);
$concesionaria->agregarVehiculo($moto1);
$concesionaria->agregarVehiculo($auto2);
$concesionaria->agregarVehiculo($moto2);


echo "<h2> Test Listado de Vehículos </h2>";
$vehiculos = $concesionaria->listar();
foreach($vehiculos as $vehiculo){
    echo $vehiculo."<br>";
}

echo "<br>-------------------------<br>";

$vehiculoMayorPrecio = $concesionaria->mayorPrecio();
echo $vehiculoMayorPrecio."<br><br>";

$vehiculoMenorPrecio = $concesionaria->menorPrecio();
echo $vehiculoMenorPrecio."<br><br>";

$vehiculoY = $concesionaria->contieneY();
echo $vehiculoY;

echo "<br>-------------------------<br>";

echo "<h2> Vehículos ordenados por precio de mayor a menor </h2>";
$concesionaria->ordenPrecio()."<br>";

echo "<br>-------------------------<br>";

echo "<h2> Vehículos ordenados por orden natural (marca, modelo, precio) </h2>";
$concesionaria->ordenNatural();
foreach($concesionaria->listar() as $vehiculo){
    echo $vehiculo."<br>";
}

?>