<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../interfaces/i_concesionaria.php";
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";


//http://localhost/objetos/tpe2/php/test/test_concesionaria.php


echo "<h1> Test TP Entregable 2 - Concesionaria </h1><br>";


// Ingreso de los registros de los vehículos.
$auto1 = new Auto("Peugeot", "206", "4", 200000.00);
$moto1 = new Moto("Honda", "Titan", "125c", 60000.00);
$auto2 = new Auto("Peugeot", "208", "5", 250000.00);
$moto2 = new Moto("Yamaha", "YBR", "160c", 80500.50);



// Creación de Concesionaria y agregado de los vehículos a Concesionaria.
$concesionaria = new Concesionaria();
$concesionaria->agregarVehiculo($auto1);
$concesionaria->agregarVehiculo($moto1);
$concesionaria->agregarVehiculo($auto2);
$concesionaria->agregarVehiculo($moto2);



echo "<h2> Test Listado de Vehículos </h2><br>";        
$vehiculos = $concesionaria->listar();
foreach($vehiculos as $vehiculo){
    echo $vehiculo."<br>";                                      // FALTA FORMATO EN LA SALIDA.
}


echo "<br>-----------------<br><br>";


echo "<h2> Test Vehículo más caro </h2><br>";
$vehiculoMayorPrecio = $concesionaria->mayorPrecio();
echo $vehiculoMayorPrecio."<br>";                               // FALTA FORMATO EN LA SALIDA.


echo "<br>-----------------<br><br>";


echo "<h2> Test Vehículo más barato </h2><br>";
$vehiculoMenorPrecio = $concesionaria->menorPrecio();
echo $vehiculoMenorPrecio;                                      // FALTA FORMATO EN LA SALIDA.



/*  -- SALIDA --

Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00 
Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00 
Marca: Peugeot // Modelo: 208 // Puertas: 5 // Precio: $250.000,00 
Marca: Yamaha // Modelo: YBR // Cilindrada: 160c // Precio: $80.500,50

=============================

Vehículo más caro: Peugeot 208 
Vehículo más barato: Honda Titan
Vehículo que contiene en el modelo la letra ‘Y’: Yamaha YBR $80.500,50

=============================
Vehículos ordenados por precio de mayor a menor:
Peugeot 208
Peugeot 206 
Yamaha YBR 
Honda Titan

=============================

Vehículos ordenados por orden natural (marca, modelo, precio):
Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00 
Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00 
Marca: Peugeot // Modelo: 208 // Puertas: 5 // Precio: $250.000,00 
Marca: Yamaha // Modelo: YBR // Cilindrada: 160c // Precio: $80.500,50

*/


?>